export class Course {
    id: string;
    name: string;
    assists: number;
    section: string;
}
