export class User {
    username: string;
    name: string;
}
